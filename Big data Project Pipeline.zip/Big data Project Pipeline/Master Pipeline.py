# Databricks notebook source
# Databricks notebook source
# ==========================================================
# MASTER PIPELINE RUNNER
# Project: Big Data Project Pipeline
# Author: Kyatham Srilaya
# Description: Executes all 5 layers sequentially
# ==========================================================

from datetime import datetime

# ---------------- CONFIGURATION ----------------
CATALOG = "workspace"
SCHEMA = "default"

# Dataset table names (adjust if needed)
SRC_FAO   = f"{CATALOG}.{SCHEMA}.faostat_data_en_11_6_2025"      # FAO dataset
SRC_CLIM  = f"{CATALOG}.{SCHEMA}.daily_delhi_climate_test"       # Climate dataset
SRC_SOIL  = f"{CATALOG}.{SCHEMA}.soil_data"                      # Soil dataset
SRC_RAIN  = f"{CATALOG}.{SCHEMA}.rainfall"                       # Rainfall dataset (if available)

# Pipeline parameters
COUNTRY   = "India"
CROP      = "Rice, paddy"
START_YR  = 2000
END_YR    = 2025

# Toggle which use-cases to run
RUN_YIELD_FORECAST   = True
RUN_RAINFALL_IMPACT  = True
RUN_CLIMATE_MATCH    = True
RUN_GDD_TIMING       = True
RUN_SOIL_RECO        = True

# Output tables (optional)
BRONZE_FAO   = f"{CATALOG}.{SCHEMA}.bronze_fao"
SILVER_FAO   = f"{CATALOG}.{SCHEMA}.silver_fao"
FEATURE_ALL  = f"{CATALOG}.{SCHEMA}.feature_dataset"

# Common parameters to send to all layers
params_common = {
    "CATALOG": CATALOG,
    "SCHEMA": SCHEMA,
    "SRC_FAO": SRC_FAO,
    "SRC_CLIM": SRC_CLIM,
    "SRC_SOIL": SRC_SOIL,
    "SRC_RAIN": SRC_RAIN,
    "COUNTRY": COUNTRY,
    "CROP": CROP,
    "START_YR": str(START_YR),
    "END_YR": str(END_YR),
    "RUN_YIELD_FORECAST": str(RUN_YIELD_FORECAST),
    "RUN_RAINFALL_IMPACT": str(RUN_RAINFALL_IMPACT),
    "RUN_CLIMATE_MATCH": str(RUN_CLIMATE_MATCH),
    "RUN_GDD_TIMING": str(RUN_GDD_TIMING),
    "RUN_SOIL_RECO": str(RUN_SOIL_RECO),
    "BRONZE_FAO": BRONZE_FAO,
    "SILVER_FAO": SILVER_FAO,
    "FEATURE_ALL": FEATURE_ALL
}

# ---------------- PIPELINE EXECUTION ----------------
print("🚀 Starting the Big Data Project Pipeline...\n")

try:
    # Bronze Layer (Raw Ingestion)
    print("➡️ Running Bronze Layer...")
    dbutils.notebook.run("/Users/kyathamsrilaya@gmail.com/Big data Project Pipeline/bronze layer", 0, params_common)
    print("✅ Bronze Layer Completed.\n")

    # Silver Layer (Cleaning / Transformation)
    print("➡️ Running Silver Layer...")
    dbutils.notebook.run("/Users/kyathamsrilaya@gmail.com/Big data Project Pipeline/Silver layer", 0, params_common)
    print("✅ Silver Layer Completed.\n")

    # Feature Engineering Layer
    print("➡️ Running Feature Engineering Layer...")
    dbutils.notebook.run("/Users/kyathamsrilaya@gmail.com/Big data Project Pipeline/Feature Engineering", 0, params_common)
    print("✅ Feature Engineering Completed.\n")

    # Models (All 5 Use Cases)
    print("➡️ Running Models Layer (All Use Cases)...")
    dbutils.notebook.run("/Users/kyathamsrilaya@gmail.com/Big data Project Pipeline/Models", 0, params_common)
    print("✅ Models Layer Completed.\n")

    # Visualizations
    print("➡️ Running Visualizations Layer...")
    dbutils.notebook.run("/Users/kyathamsrilaya@gmail.com/Big data Project Pipeline/Visualizations", 0, params_common)
    print("✅ Visualizations Completed.\n")

    print("🎉 PIPELINE EXECUTION SUCCESSFUL!")
    print(f"✅ Country: {COUNTRY} | Crop: {CROP} | Years: {START_YR}-{END_YR}")

except Exception as e:
    print("\n❌ PIPELINE FAILED ❌")
    print(f"Error: {str(e)}")
    raise e
