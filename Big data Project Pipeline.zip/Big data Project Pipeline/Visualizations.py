# Databricks notebook source
# Databricks notebook source
# Tip: This notebook just ensures output tables exist for SQL charting.
# Open each saved table and click the ➕ (visualization) button in the UI.

for k in ["TB_YIELD_FC","TB_RAIN_IMP","TB_CLIM_MATCH","TB_GDD_SUM","TB_SOIL_REC"]:
  dbutils.widgets.text(k,""); globals()[k]=dbutils.widgets.get(k)

print("📊 Ready to visualize these tables (create charts in the UI):")
print("•", TB_YIELD_FC)
print("•", TB_RAIN_IMP)
print("•", TB_CLIM_MATCH)
print("•", TB_GDD_SUM)
print("•", TB_SOIL_REC)
