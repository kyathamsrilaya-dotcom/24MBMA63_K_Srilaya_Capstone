# Databricks notebook source
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("BronzeLayer").getOrCreate()

# Read directly from your uploaded FAOSTAT table
bronze_df = spark.table("workspace.default.faostat_data_en_11_6_2025")

# ✅ Step 1: Clean column names — replace spaces and special chars with underscores
for col in bronze_df.columns:
    safe_col = col.replace(" ", "_").replace("(", "").replace(")", "").replace("-", "_").replace("/", "_")
    bronze_df = bronze_df.withColumnRenamed(col, safe_col)

# ✅ Step 2: Save as Delta table
bronze_df.write.mode("overwrite").saveAsTable("workspace.default.bronze_faostat_data")

print("✅ Bronze Layer successfully created: workspace.default.bronze_faostat_data")


# COMMAND ----------

# MAGIC %md
# MAGIC