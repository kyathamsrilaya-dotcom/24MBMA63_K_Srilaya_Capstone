# Databricks notebook source
# Databricks notebook source
for k in ["SILVER_FAO","SILVER_CLIM","SILVER_RAIN","SILVER_SOIL","FEATURE_ALL",
          "COUNTRY","CROP","START_YR","END_YR"]:
  dbutils.widgets.text(k,""); globals()[k]=dbutils.widgets.get(k)

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql import SparkSession
spark=SparkSession.builder.getOrCreate()
START_YR=int(START_YR or 0); END_YR=int(END_YR or 9999)

def ok(t):
  try:
    p=t.split("."); return spark.catalog.tableExists(".".join(p[:2]), p[2])
  except: return False

feats=[]

# Yield (per year)
if ok(SILVER_FAO):
    y = spark.table(SILVER_FAO).select("year","yield").dropna()
    w=Window.orderBy("year").rowsBetween(-2,0)
    y = (y.withColumn("yield_ma3", F.avg("yield").over(w)))
    feats.append(y)

# Climate annual aggregates
if ok(SILVER_CLIM):
    c = (spark.table(SILVER_CLIM)
         .groupBy("year")
         .agg(F.avg("meantemp").alias("tavg"),
              F.avg("humidity").alias("humidity_avg"),
              F.avg("wind_speed").alias("wind_avg"),
              F.avg("meanpressure").alias("p_avg")))
    feats.append(c)

# Rainfall by year (sum)
if ok(SILVER_RAIN):
    r = (spark.table(SILVER_RAIN)
         .groupBy("year")
         .agg(F.sum("rainfall_mm").alias("rainfall_total")))
    feats.append(r)

from functools import reduce
from pyspark.sql import DataFrame

if feats:
    df = reduce(lambda a,b: a.join(b, "year", "outer"), feats).orderBy("year")
    df.write.mode("overwrite").saveAsTable(FEATURE_ALL)
    print(f"✅ Feature table written: {FEATURE_ALL}")
else:
    print("⚠️ No feature inputs available; skipping.")

