# Databricks notebook source
# Databricks notebook source
# Inputs / outputs / flags
keys = ["FEATURE_ALL","SILVER_CLIM","SILVER_SOIL","SILVER_RAIN",
        "TB_YIELD_FC","TB_RAIN_IMP","TB_CLIM_MATCH","TB_GDD_SUM","TB_SOIL_REC",
        "RUN_YIELD_FORECAST","RUN_RAINFALL_IMPACT","RUN_CLIMATE_MATCH","RUN_GDD_TIMING","RUN_SOIL_RECO"]
for k in keys: dbutils.widgets.text(k,""); globals()[k]=dbutils.widgets.get(k)

from pyspark.sql import functions as F
from pyspark.sql import SparkSession
spark=SparkSession.builder.getOrCreate()

def table_ok(t):
    try:
        p=t.split("."); return spark.catalog.tableExists(".".join(p[:2]), p[2])
    except: return False

# ---------- Use Case 1: Yield Forecast (robust fallback) ----------
if (RUN_YIELD_FORECAST.lower()=="true") and table_ok(FEATURE_ALL):
    pdf = spark.table(FEATURE_ALL).select("year","yield").dropna().orderBy("year").toPandas()
    if len(pdf)>=3:
        # Try Prophet, else fallback to simple linear regression with scikit-learn
        forecast_pdf=None
        try:
            import sys, subprocess
            try:
                import prophet # may raise
            except:
                subprocess.check_call([sys.executable,"-m","pip","install","prophet","--quiet"])
            from prophet import Prophet
            pdf2=pdf.rename(columns={"year":"ds","yield":"y"})
            # Convert ds to datetime as Jan-01 of year
            import pandas as pd
            pdf2["ds"]=pd.to_datetime(pdf2["ds"].astype(str)+"-01-01")
            m=Prophet()
            m.fit(pdf2)
            future=m.make_future_dataframe(periods=5, freq="Y")
            fc=m.predict(future)
            out = fc[["ds","yhat","yhat_lower","yhat_upper"]].tail(5)
            out["year"]=out["ds"].dt.year
            forecast_pdf=out[["year","yhat","yhat_lower","yhat_upper"]]
        except Exception as e:
            # Fallback simple linear trend
            from sklearn.linear_model import LinearRegression
            import numpy as np, pandas as pd
            X=pdf[["year"]].values; y=pdf["yield"].values
            model=LinearRegression().fit(X,y)
            years=list(range(int(pdf["year"].max())+1, int(pdf["year"].max())+6))
            yh=model.predict(np.array(years).reshape(-1,1))
            forecast_pdf=pd.DataFrame({"year":years,"yhat":yh,
                                       "yhat_lower":yh*0.98, "yhat_upper":yh*1.02})
        spark.createDataFrame(forecast_pdf).write.mode("overwrite").saveAsTable(TB_YIELD_FC)
        print(f"✅ Yield forecast saved: {TB_YIELD_FC}")
    else:
        print("⚠️ Not enough rows for forecasting (need ≥3).")

# ---------- Use Case 2: Rainfall Impact ----------
if (RUN_RAINFALL_IMPACT.lower()=="true") and table_ok(FEATURE_ALL):
    df = spark.table(FEATURE_ALL).select("year","yield","rainfall_total")
    df = df.where(F.col("yield").isNotNull() & F.col("rainfall_total").isNotNull())
    if df.count()>1:
        corr = df.select(F.corr("rainfall_total","yield").alias("corr")).collect()[0]["corr"]
        by_period = df.groupBy("year").agg(F.first("rainfall_total").alias("rainfall_mm"),
                                           F.first("yield").alias("yield"))
        (by_period.withColumn("corr_year_vs_yield", F.lit(corr))
         .orderBy("year")
         .write.mode("overwrite").saveAsTable(TB_RAIN_IMP))
        print(f"✅ Rainfall impact saved: {TB_RAIN_IMP} (corr={corr:.3f})")
    else:
        print("⚠️ Insufficient data for rainfall impact.")

# ---------- Use Case 3: Simple Climate Matching ----------
# Top-K years with most similar climate (using z-score distance across tavg, humidity_avg, wind_avg, p_avg)
if (RUN_CLIMATE_MATCH.lower()=="true") and table_ok(FEATURE_ALL):
    feat = spark.table(FEATURE_ALL).select("year","tavg","humidity_avg","wind_avg","p_avg").dropna()
    if feat.count()>5:
        cols=["tavg","humidity_avg","wind_avg","p_avg"]
        stats = feat.select(*[F.avg(c).alias(f"{c}_m") for c in cols],
                            *[F.stddev(c).alias(f"{c}_s") for c in cols]).collect()[0].asDict()
        z = feat
        for c in cols:
            z = z.withColumn(f"z_{c}", (F.col(c)-F.lit(stats[f"{c}_m"]))/(F.lit(stats[f"{c}_s"])+1e-9))
        # similarity to the most recent year
        last_year = z.agg(F.max("year")).first()[0]
        ref = z.where(F.col("year")==last_year).select(*[f"z_{c}" for c in cols]).first().asDict()
        dist = z.withColumn("dist",
                            sum((F.col(f"z_{c}")-F.lit(ref[f"z_{c}"]))**2 for c in cols))
        topk = (dist.orderBy("dist").limit(6))  # include last year itself
        topk.write.mode("overwrite").saveAsTable(TB_CLIM_MATCH)
        print(f"✅ Climate match saved: {TB_CLIM_MATCH}")
    else:
        print("⚠️ Not enough climate rows for matching.")

# ---------- Use Case 4: GDD Timing ----------
# For climate daily table, estimate GDD base10 from meantemp and find date when cumulative GDD crosses 1200
if (RUN_GDD_TIMING.lower()=="true") and table_ok(SILVER_CLIM):
    c = spark.table(SILVER_CLIM).select("date","year","meantemp").dropna()
    if c.count()>0:
        c = c.withColumn("gdd", F.greatest(F.col("meantemp")-F.lit(10.0), F.lit(0.0)))
        w = (Window.partitionBy("year").orderBy("date")
             .rowsBetween(Window.unboundedPreceding, Window.currentRow))
        from pyspark.sql import Window
        cum = c.withColumn("cum_gdd", F.sum("gdd").over(w))
        # threshold
        thresh = (cum.where(F.col("cum_gdd")>=1200)
                  .groupBy("year").agg(F.min("date").alias("threshold_date")))
        thresh.write.mode("overwrite").saveAsTable(TB_GDD_SUM)
        print(f"✅ GDD timing saved: {TB_GDD_SUM}")
    else:
        print("⚠️ No rows in climate daily for GDD.")

# ---------- Use Case 5: Soil Recommendation (rule-based) ----------
if (RUN_SOIL_RECO.lower()=="true") and table_ok(SILVER_SOIL):
    s = spark.table(SILVER_SOIL)
    # Simple rules (demo): thresholds for N/P/K
    rec = (s.withColumn("n_level", F.when(F.col("n")<100,"Low").when(F.col("n")<200,"Medium").otherwise("High"))
             .withColumn("p_level", F.when(F.col("p")<50,"Low").when(F.col("p")<100,"Medium").otherwise("High"))
             .withColumn("k_level", F.when(F.col("k")<80,"Low").when(F.col("k")<150,"Medium").otherwise("High"))
             .withColumn("recommendation",
                         F.when((F.col("n_level")=="Low")&(F.col("p_level")=="Low")&(F.col("k_level")=="Low"),
                                F.lit("Apply NPK 10:26:26 @ moderate dose"))
                          .when(F.col("n_level")=="Low", F.lit("Add urea (N)"))
                          .when(F.col("p_level")=="Low", F.lit("Add SSP/DAP (P)"))
                          .when(F.col("k_level")=="Low", F.lit("Add MOP (K)"))
                          .otherwise(F.lit("Maintain dose; add compost"))))
    rec.write.mode("overwrite").saveAsTable(TB_SOIL_REC)
    print(f"✅ Soil recommendation saved: {TB_SOIL_REC}")

print("✅ Use-cases finished.")
