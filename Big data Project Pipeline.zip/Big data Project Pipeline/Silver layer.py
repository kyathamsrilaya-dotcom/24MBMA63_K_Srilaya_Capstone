# Databricks notebook source
# Databricks notebook source
# Widgets / params
keys = ["CATALOG","SCHEMA","COUNTRY","CROP","START_YR","END_YR",
        "BRONZE_FAO","BRONZE_CLIM","BRONZE_RAIN","BRONZE_SOIL",
        "SILVER_FAO","SILVER_CLIM","SILVER_RAIN","SILVER_SOIL"]
for k in keys: dbutils.widgets.text(k,""); globals()[k]=dbutils.widgets.get(k)
START_YR=int(START_YR or 0); END_YR=int(END_YR or 9999)

from pyspark.sql import functions as F
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()

def table_ok(t): 
    try:
        return len(t.split("."))==3 and spark.catalog.tableExists(".".join(t.split(".")[:2]), t.split(".")[2])
    except: return False

# --- FAO (yield) ---
if table_ok(BRONZE_FAO):
    fao = spark.table(BRONZE_FAO)
    # Try to standardize: expect columns like ['Area','Item','Year','Value'] or similar
    cols = [c.lower().replace(" ","_") for c in fao.columns]
    fao = fao.toDF(*cols)
    # Best-effort mapping
    c_area  = [c for c in fao.columns if c in ("area","country","country_area")]
    c_item  = [c for c in fao.columns if c in ("item","crop","crop_name")]
    c_year  = [c for c in fao.columns if c in ("year","yr")]
    c_value = [c for c in fao.columns if c in ("value","yield","yield_t_ha","yld")]
    if c_area and c_item and c_year and c_value:
        fao = (fao
               .withColumnRenamed(c_area[0], "country")
               .withColumnRenamed(c_item[0], "crop")
               .withColumnRenamed(c_year[0], "year")
               .withColumnRenamed(c_value[0], "yield")
               .withColumn("year", F.col("year").cast("int"))
               .withColumn("yield", F.col("yield").cast("double"))
               .filter((F.col("country")==COUNTRY) & (F.col("crop")==CROP))
               .filter((F.col("year")>=START_YR) & (F.col("year")<=END_YR))
        )
        fao.write.mode("overwrite").saveAsTable(SILVER_FAO)
        print(f"✅ Silver FAO: {SILVER_FAO}")
    else:
        print("⚠️ Could not standardize FAO table (missing expected columns).")

# --- Climate (daily) ---
if table_ok(BRONZE_CLIM):
    clim = spark.table(BRONZE_CLIM)
    cc = [c.lower().replace(" ","_") for c in clim.columns]
    clim = clim.toDF(*cc)
    # common columns in 'daily_delhi_climate' style: date, meantemp, humidity, wind_speed, meanpressure
    need = {"date":"date","meantemp":"meantemp","humidity":"humidity","wind_speed":"wind_speed","meanpressure":"meanpressure"}
    # soft map
    m={}
    for dst in need:
        cand=[c for c in clim.columns if c==dst or c.endswith(dst) or dst in c]
        if cand: m[dst]=cand[0]
    if set(m.keys())>=set(need.keys()):
        clim = clim.select([F.col(m[k]).alias(k) for k in need.keys()]) \
                   .withColumn("date", F.to_date("date")) \
                   .withColumn("year", F.year("date")) \
                   .filter((F.col("year")>=START_YR) & (F.col("year")<=END_YR))
        clim.write.mode("overwrite").saveAsTable(SILVER_CLIM)
        print(f"✅ Silver Climate: {SILVER_CLIM}")
    else:
        print("⚠️ Could not standardize climate table (need date, meantemp, humidity, wind_speed, meanpressure).")

# --- Rainfall (monthly) ---
if table_ok(BRONZE_RAIN):
    r = spark.table(BRONZE_RAIN)
    rc=[c.lower().replace(" ","_") for c in r.columns]; r=r.toDF(*rc)
    # Expect: year, month (or season label), rainfall (mm)
    y = [c for c in r.columns if c in ("year","yr")]
    m = [c for c in r.columns if c in ("month","mon","season","label")]
    v = [c for c in r.columns if "rain" in c]
    if y and m and v:
        r = (r.withColumnRenamed(y[0],"year")
              .withColumnRenamed(m[0],"period")
              .withColumnRenamed(v[0],"rainfall_mm")
              .withColumn("year",F.col("year").cast("int"))
              .withColumn("rainfall_mm",F.col("rainfall_mm").cast("double"))
              .filter((F.col("year")>=START_YR)&(F.col("year")<=END_YR)))
        r.write.mode("overwrite").saveAsTable(SILVER_RAIN)
        print(f"✅ Silver Rainfall: {SILVER_RAIN}")
    else:
        print("⚠️ Could not standardize rainfall table (need year, month/season, rainfall col).")

# --- Soil (NPK) ---
if table_ok(BRONZE_SOIL):
    s = spark.table(BRONZE_SOIL)
    sc=[c.lower().replace(" ","_") for c in s.columns]; s=s.toDF(*sc)
    # Expect: location/region, n, p, k, soil_type (free-form)
    loc=[c for c in s.columns if c in ("region","state","district","location","area","site")]
    n=[c for c in s.columns if c in ("n","nitrogen")]
    p=[c for c in s.columns if c in ("p","phosphorus","phosphorous")]
    k=[c for c in s.columns if c in ("k","potassium")]
    st=[c for c in s.columns if "soil" in c]
    if (n and p and k):
        if loc: s=s.withColumnRenamed(loc[0],"region")
        if st:  s=s.withColumnRenamed(st[0],"soil_type")
        s=s.withColumnRenamed(n[0],"n").withColumnRenamed(p[0],"p").withColumnRenamed(k[0],"k")
        for c in ["n","p","k"]: s=s.withColumn(c,F.col(c).cast("double"))
        s.write.mode("overwrite").saveAsTable(SILVER_SOIL)
        print(f"✅ Silver Soil: {SILVER_SOIL}")
    else:
        print("⚠️ Could not standardize soil table (need N/P/K columns).")

print("✅ Silver layer complete.")
